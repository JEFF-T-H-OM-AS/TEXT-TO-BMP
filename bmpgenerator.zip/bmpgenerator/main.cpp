#include "bmp.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    bmp w;
   // w.show();
    return a.exec();
}
